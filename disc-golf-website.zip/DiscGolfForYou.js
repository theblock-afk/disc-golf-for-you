import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { useState } from "react";

export default function DiscGolfForYou() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message sent! We'll get back to you soon.");
  };

  return (
    <div className="min-h-screen bg-red-600 text-white p-6 space-y-10">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Disc Golf For You</h1>
        <p className="text-lg mt-2">Premium Disc Golf Discs for Every Player</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((item) => (
          <Card key={item} className="bg-white text-black rounded-2xl shadow-md">
            <CardContent className="p-4">
              <img src={`/disc-${item}.png`} alt="Disc Golf Disc" className="w-full rounded-xl" />
              <h2 className="text-xl font-semibold mt-4">Disc Model {item}</h2>
              <p className="text-sm mt-2">A great all-around disc for beginners and pros alike.</p>
              <Button className="mt-4 w-full">Add to Cart</Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="max-w-xl mx-auto mt-16">
        <h2 className="text-2xl font-semibold mb-4 text-center">Contact Us</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <Input
            name="email"
            type="email"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <Input
            name="message"
            placeholder="Your Message"
            value={formData.message}
            onChange={handleChange}
            required
          />
          <Button type="submit" className="w-full">Send Message</Button>
        </form>
      </section>
    </div>
  );
}
